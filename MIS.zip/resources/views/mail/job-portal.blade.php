<div class="h2">
    <b>{{$name}}</b>,
    <br>
    <br>
    Thanks for taking the time to apply for <b>{{$designation}}</b>. We appreciate your interest in <b>Tech Nerds.</b>
    <br>
    <br>
    We're currently in the process of taking applications for this position. If you are selected to continue to the interview process, our human resources department will be in contact with you soon.
    <br>
    <br>
    Thank you,
    <br>
    Tech Nerds
    <br>
    https://technerds.com/<br>
    +92-42-35315372
</div>