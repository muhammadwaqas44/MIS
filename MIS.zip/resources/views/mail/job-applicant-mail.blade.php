<h1>Applicant details</h1>
<p>Job Title: {{$apply_for}}<br>
    Name : {{$name}}<br>
    Email : {{$email}}<br>
    Phone Number : {{$phone}}<br>
    Address : {{$address}}<br>
    City: {{$city}}<br>
    Skype ID : {{$skype}}<br>
    Experience : {{$experience}}<br>
    Expected Salary : {{$salary}}<br>
</p>